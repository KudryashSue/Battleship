package battleship;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    private static final int BOARD_LENGTH = 10;
    private static final char FOG_CELL = '~';
    private static final char SHIP_CELL = 'O';
    private static final char HIT_CELL = 'X';
    private static final char MISS_CELL = 'M';
    static Scanner scanner = new Scanner(System.in);

    private static char[][] playerField;

    public static void main(String[] args) {
        createPlayerField();
        placeShips();
    }

    private static void createPlayerField() {

        playerField = new char[BOARD_LENGTH][BOARD_LENGTH];
        for (char[] row : playerField) {
            Arrays.fill(row, FOG_CELL);
        }
    }

    private static void printPlayerField(char[][] board) {
        System.out.print("  ");
        for (int i = 1; i <= BOARD_LENGTH; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        char letter = 'A';
        for (char[] row : board) {
            System.out.print(letter);
            for (char cell : row) {
                System.out.print(" " + cell);
            }
            System.out.println();
            letter++;
        }
        //System.out.println(Arrays.toString(row));
    }

    private static void placeShips() {
        int[][] shipSizes = {{5, 1}, {4, 1}, {3, 2}, {2, 1}};
        for (int i = 0; i < shipSizes.length; i++) {
            int shipSize = shipSizes[i][0];
            int shipCount = shipSizes[i][1];
            for (int j = 0; j < shipCount; j++) {
                boolean validPlacement = false;
                while (!validPlacement) {
                    printPlayerField(playerField);
                    System.out.printf("Enter the coordinates of the %s (%d cells):%n", getShipName(shipSize), shipSize);
                    String startInput = scanner.nextLine();
                    String endInput = scanner.nextLine();

                    try {
                        int[] startCoordinate = parseCoordinate(startInput);
                        int[] endCoordinate = parseCoordinate(endInput);

                        checkCoordinates(startCoordinate, endCoordinate, shipSize);
                        checkPlacement(startCoordinate, endCoordinate);
                        placeShip(startCoordinate, endCoordinate);

                        validPlacement = true;
                    } catch (Exception e) {
                        System.out.println("Error! " + e.getMessage());
                    }
                }
            }
        }
    }

    private static String getShipName(int shipSize) {
        switch (shipSize) {
            case 2:
                return "Destroyer";
            case 3:
                return "Cruiser/Submarine";
            case 4:
                return "Battleship";
            case 5:
                return "Aircraft Carrier";
            default:
                return "";
        }
    }

    private static int[] parseCoordinate (String coordinate) throws Exception {
        if (coordinate.length() < 2 || coordinate.length() > 3) {
            throw new Exception("Invalid coordinate format.");
        }

        char rowChar = Character.toUpperCase(coordinate.charAt(0));
        int column = Integer.parseInt(String.valueOf(coordinate.charAt(1)));
        int row = rowChar - 'A';

        if (rowChar < 'A' || rowChar >= 'A' + BOARD_LENGTH - 1 || column < 1 || column > BOARD_LENGTH) {
            throw new Exception("Invalid coordinate range.");
        }

        return new int[]{row, column - 1};
    }

    private static void checkCoordinates(int[] startCoordinate, int[] endCoordinate, int shipSize) throws Exception {
        if (startCoordinate[0] != endCoordinate[0] && startCoordinate[1] != endCoordinate[1]) {
            throw new Exception("Wrong ship location! Try again:");
        }

        int shipLength = Math.max(Math.abs(endCoordinate[0] - startCoordinate[0]), Math.abs(endCoordinate[1] - startCoordinate[1])) + 1;
        if (shipLength != shipSize) {
            throw new Exception("Wrong length of the ship! ");
        }
    }

    private static void checkPlacement(int[] startCoordinate, int[] endCoordinate) throws Exception {
        int startRow = startCoordinate[0];
        int startColumn = startCoordinate[1];
        int endRow = endCoordinate[0];
        int endColumn = endCoordinate[1];

        for (int row = startRow; row <= endRow; row++) {
            for (int column = startColumn; column <= endColumn; column++) {
                if (playerField[row][column] == SHIP_CELL) {
                    throw new IllegalArgumentException("Ships cannot overlap.");
                }

                for (int i = Math.max(0, row - 1); i <= Math.min(row + 1, BOARD_LENGTH - 1); i++) {
                    for (int j = Math.max(0, column - 1); j <= Math.min(column + 1, BOARD_LENGTH - 1); j++) {
                        if (playerField[i][j] == SHIP_CELL) {
                            throw new IllegalArgumentException("You placed it too close to another one. Try again:");
                        }
                    }
                }
            }
        }
    }

    private static void placeShip(int[] startCoordinate, int[] endCoordinate) {
        int startRow = startCoordinate[0];
        int startCol = startCoordinate[1];
        int endRow = endCoordinate[0];
        int endCol = endCoordinate[1];

        for (int row = startRow; row <= endRow; row++) {
            for (int col = startCol; col <= endCol; col++) {
                playerField[row][col] = SHIP_CELL;
            }
        }
    }
}
